<?php init_head(); ?>


<script type="text/javascript">
  function AddLeave()
 {    
    $('#ticket-service-modal').modal('show');
    //$('.add-title').addClass('hide');
 }
  function editleave_quota(id,category,quota)
 {
    $("#leaveid").val(id);
    $("#leavename").val(category);
    $("#leavequota").val(quota);   
    $('#edit-Leave-quota-modal').modal('show');
 }
</script>
<div id="wrapper"><?php init_clockinout(); ?>
   <div class="content">
      <div class="row">
         <div class="col-md-12">
            <div class="panel_s">
               <div class="panel-body">
                  <div class="_buttons">
                   
                    <div class="nav-tabs-custom">
                      <ul class="nav nav-tabs">
                        <li class="active"><a href="#pending_approval" data-toggle="tab">Pending Approval</a>
                        </li>
                        <li class=""><a href="#my_leave" data-toggle="tab">My Leave</a></li>
                        <li class=""><a href="#holidays" data-toggle="tab">Holidays</a></li>
                        <li class="pull-right">
                          <a href="#" class="bg-info "  onclick="AddLeave()" ></i> Apply Leave </a>
                        </li>
                    </ul>
                    </div>
                            <div class="row">
                                <div class="tab-content" style="border: 0;padding:0;">

                   <?php if(!empty($this->session->flashdata('success'))) {?>
                       <div class="text-success text-center"><?php echo  $this->session->flashdata('success'); ?></div>
                   <?php }else if(!empty($this->session->flashdata('error'))){?>
                       <div class="text-danger text-center"><?php echo  $this->session->flashdata('error'); ?></div>
                   <?php } ?>

                <div class="tab-pane active" id="pending_approval" style="position: relative;">
                  <div class="panel panel-custom">
                    <div class="panel-body">
					
					         <?php if(count($pendingApproval)>0) {?>
                            <div class="table-responsive">
                                <div id="DataTables_wrapper" class="dataTables_wrapper form-inline no-footer">
                                  <div class="dataTables_length" id="DataTables_length"><label>
                                    <select name="DataTables_length" aria-controls="DataTables" class="form-control input-sm"><option value="10">10</option><option value="20">20</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>
                                  </label>
                                </div>
                                <!-- <div id="DataTables_filter" class="dataTables_filter">
                                <label>Search all columns:
                                <input type="search" class="form-control input-sm" placeholder="" aria-controls="DataTables">
                                </label></div> -->
                                 
                                  <table class="table table-striped DataTables  dataTable no-footer dtr-inline" id="pending_approval_table" cellspacing="0" width="100%" role="grid" aria-describedby="DataTables_info" style="width: 100%;">
                                    <thead>
                                    <tr role="row">
                                      <th style="width: 154px;" >Name</th>
                                      <th style="width: 337px;">Leave Category</th>
                                      <th style="width: 128px;">Date</th>

                                      <th style="width: 210px;" >Duration</th>
                                      <th style="width: 161px;" >Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    
                                    
                                     <?php foreach($pendingApproval as $pendingLeave) { ?>
                                       <tr class="odd">
                                      <td ><?php echo  ucfirst(substr($pendingLeave->reason,0,10)); ?></td>
                                      <td><?php 

                                        $catId=$pendingLeave->leave_category_id;
                                        $this->db->where('leave_category_id',$catId); 
                                         $category=$this->db->get('tblleavecategory')->result(); 
                                         if($category)
                                         {
                                          echo  $category[0]->leave_category; 
                                         } 

                                           ?></td>
                                      <td>
                                        <?php echo date('j M, Y',strtotime($pendingLeave->leave_start_date)).'-To-'.date('j M, Y',strtotime($pendingLeave->leave_end_date)); ?>
                                       </td>
                                       
                                       <td><?= $pendingLeave->duration ?></td>
                                      

                                      <td><?php if($pendingLeave->application_status=='1') { ?>
                                          <button style="cursor: none;" class="btn btn-xs btn-danger">Pending</button>
                                        <?php  } ?></td>
                                    </tr>     
                                    <?php }?>
                                    </tbody>
                                </table>
                            </div>
                            </div>
							
							 <?php }else{?>
							      <div class="text-danger text-center">No Records ...</div>
							 <?php }?>
							
							
							
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="my_leave" style="position: relative;">
                    <div class="panel panel-custom">
                        <div class="panel-body">
						   <?php if(count($Approvalleave)>0) {?>
                          <div class="table-responsive">
                                <div id="DataTables_wrapper" class="dataTables_wrapper form-inline no-footer">
                                  <div class="dataTables_length" id="DataTables_length"><label>
                                    <select name="DataTables_length" aria-controls="DataTables" class="form-control input-sm"><option value="10">10</option><option value="20">20</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>
                                  </label>
                                </div>
                                <!-- <div id="DataTables_filter" class="dataTables_filter">
                                <label>Search all columns:
                                <input type="search" class="form-control input-sm" placeholder="" aria-controls="DataTables">
                                </label></div>-->

                                  <table class="table table-striped DataTables  dataTable no-footer dtr-inline" id="pending_approval_table" cellspacing="0" width="100%" role="grid" aria-describedby="DataTables_info" style="width: 100%;">
                                    <thead>
                                    <tr role="row">

                                      <th class="sorting_asc" tabindex="0" aria-controls="DataTables" style="width: 154px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Reason</th>
                                      <th class="sorting" tabindex="0" aria-controls="DataTables" rowspan="1" colspan="1" style="width: 337px;" aria-label="Leave Category: activate to sort column ascending">Leave Category</th>
                                      <th class="sorting" tabindex="0" aria-controls="DataTables" style="width: 128px;" aria-label="Date: activate to sort column ascending">Date</th>

                                      <th class="sorting" tabindex="0" aria-controls="DataTables" style="width: 105px;" aria-label="Duration: activate to sort column ascending">Duration</th>
                                      <!--<th class="sorting" tabindex="0" aria-controls="DataTables" style="width: 105px;" aria-label="Duration: activate to sort column ascending">Attachment</th>
                                     -->
                                      <th class="sorting" tabindex="0" aria-controls="DataTables" style="width: 161px;" aria-label="Status: activate to sort column ascending">Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    
                                    
                                     <?php foreach($Approvalleave as $Aleave) { ?>
                                       <tr class="odd">
                                      <td ><?php echo  ucfirst(substr($Aleave->reason,0,10)); ?></td>
                                      <td> <?php $catId=$Aleave->leave_category_id;  $this->db->where('leave_category_id',$catId);  $category=$this->db->get('tblleavecategory')->result(); 
                                      if($category)
                                         {
                                          echo  $category[0]->leave_category; 
                                         } 
                                          ?></td>
                                      <td >

                                        <!--<?php echo date('j M, Y g:i a',strtotime($Aleave->leave_start_date)); ?> -->
                                        <?php if( $Aleave->leave_type == "multiple_days"){ echo date('j M, Y',strtotime($Aleave->leave_start_date)).' -To- '.date('j M,Y',strtotime($Aleave->leave_end_date)); } else { echo   date('j M, Y',strtotime($Aleave->leave_start_date)); }  ?>
                                      <!--  <?php echo date('j M, Y',strtotime($Aleave->leave_start_date)).' -To- '.date('j M,Y',strtotime($Aleave->leave_end_date)); ?> -->
                                       </td>
                                       
                                        <td><?= $Aleave->duration?></td>
                                       <!-- <td><img src="<?php echo base_url()."assets/attachment"/".$Aleave->attachment;"?>" /> </td>
-->
                                      <td><?php if($Aleave->application_status=='2') { ?>
                                          <button style="cursor: none;" class="btn btn-xs btn-success">Accepted.</button>
                                        <?php  } ?></td>
                                   
                                      
                                    
                                    </tr>     
                                    <?php }?>

                                    </tbody>
                                       <tbody>
                                    
                                    
                                     <?php foreach($Rejectedleave as $Rleave) { ?>
                                       <tr class="odd">
                                      <td ><?php echo  ucfirst(substr($Rleave->reason,0,10)); ?></td>
                                      <td> <?php $catIdR=$Rleave->leave_category_id;  $this->db->where('leave_category_id',$catId);  $category=$this->db->get('tblleavecategory')->result(); 
                                      if($category)
                                         {
                                          echo  $category[0]->leave_category; 
                                         } 
                                          ?></td>
                                      <td colspan="2">

                                        <!--<?php echo date('j M, Y g:i a',strtotime($Aleave->leave_start_date)); ?> -->
                                        <?php echo date('j M, Y',strtotime($Rleave->leave_start_date)).'-To-'.date('j M,Y',strtotime($Rleave->leave_end_date)); ?>
                                       </td>
                                       
                                       
                                      <td><?php if($Rleave->application_status=='3') { ?>
                                          <button  style="cursor: none;" class="btn btn-xs btn-danger">Rejected.</button>
                                        <?php  } ?></td>
                                   
                                      
                                    
                                    </tr>     
                                    <?php }?>

                                    </tbody>
                                </table>
                            

                            </div>
                            </div>
							
							<?php }else{?>
							      <div class="text-danger text-center">No Records ...</div>
							 <?php }?>
                        </div>
                    </div>

                </div>
                <div class="tab-pane" id="holidays" style="position: relative;">
                    <div class="panel panel-custom">
                        <div class="panel-body">
                            
                          <div class="table-responsive">
                                <div id="DataTables_wrapper" class="dataTables_wrapper form-inline no-footer">
                                  <div class="dataTables_length" id="DataTables_length"><label>
                                    <select name="DataTables_length" aria-controls="DataTables" class="form-control input-sm"><option value="10">10</option><option value="20">20</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>
                                  </label>
                                </div>
                                <!-- <div id="DataTables_filter" class="dataTables_filter">
                                <label>Search all columns:
                                <input type="search" class="form-control input-sm" placeholder="" aria-controls="DataTables">
                                </label></div>-->

                                  <table class="table table-striped DataTables  dataTable no-footer dtr-inline" id="holidays_table" cellspacing="0" width="100%" role="grid" aria-describedby="DataTables_info" style="width: 100%;">
                                    <thead>
                                    <tr role="row">

                                     <th style="width: 154px;" >Name</th>                                     
                                     
                                     <th style="width: 210px;">Leave Type</th>
                                      
                                      <th style="width: 210px;">Start Date</th>
                                      
                                      <th style="width: 210px;">End Date</th>
                                      
                                      <th style="width: 210px;">Duration</th>
                                    </thead>
                                    <tbody>
                                    
                                    
                                     <?php foreach($ourholidays as $hol) { ?>
                                   
                                       <tr class="odd">
                                      <td ><?php echo  $hol->name; ?></td>
                                      <td><?php if( $hol->leave_type == "multiple_days"){ echo "Multiple Days"; } else { echo  "Single Day"; }  ?></td>
                                      <td><?php echo  $hol->quota; ?></td>
                                      <td><?php   if( $hol->leave_type == "multiple_days"){ echo $hol->leave_end_date; } else { echo  "N/A"; } ?></td>
                                      <td><?php echo  $hol->days; ?></td>
                                     
                                      
                                      
                                    
                                    </tr>     
                                    <?php }?>

                                    </tbody>
                                      
                                </table>
                            

                            </div>
                            </div>
							
							
                        </div>
                    </div>

                </div>
              
                


                                </div>

                            </div>
                </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<div class="modal fade" id="edit-Leave-quota-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <form autocomplete="off" action="<?php echo  base_url(); ?>admin/leave/updateleave" id="ticket-service-form" method="post" accept-charset="utf-8">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">
                        <span class="edit-title">Edit Leave</span>
                        <!-- <span class="add-title">New Product</span> -->
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div id="additional"></div>
                            <div class="form-group" app-field-wrapper="name">
                              <label for="name" class="control-label">Leave Name</label>
                              <input type="text" id="leavename" name="leavename" class="form-control"  value="">
                              <input type="hidden" id="leaveid" name="leaveid" class="form-control"  value="">
                            </div>
                            <div class="form-group" app-field-wrapper="name">
                              <label for="name" class="control-label">Quota</label>
                              <input type="text" id="leavequota" name="leavequota" class="form-control"  value="">
                            </div> 

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-info">Save</button>
                </div>
            </div><!-- /.modal-content -->
            </form>        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


<div class="modal fade" id="ticket-service-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" style="width: 1000px;">
          <!--   <form action=""  method="post" accept-charset="utf-8" > -->
<input type="hidden" name="csrf_token_name" value="70b7e1b0a91ba66b991a5ea162fb3753" />                       
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">
                        <span class="edit-title">Add New  Leave</span>
                       <!--  <span class="add-title"> New Leave</span> -->
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-8">
                          <div class="alertmessage"></div> <!-- Save-leave-form -->
                <form autocomplete="off" id="" action="<?php echo base_url(); ?>admin/leave/saveleave" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <div class="panel_controls">
                            <input type="hidden" id="user_id" value="17">
                            <div class="form-group">
                            <label for="field-1" class="col-sm-4 control-label">Leave Category<span class="required"> *</span></label>

                            <div class="col-sm-8 ">
                                <select name="leave_category_id" style="width: 100%" class="form-control select_box select2-hidden-accessible" id="leave_category_id" required="" data-parsley-id="4" tabindex="-1" aria-hidden="true">
                                    <option value="">Select Leave Category</option>
                                    <?php $i=1;  $total_Approveleave=0; 
                                     foreach($leaveCategory as $category) {
                                        $catId=$category['leave_category_id']; 
                                        $this->db->where('leave_category_id',$catId); 
                                        $this->db->where('application_status','2'); 
										$loginid=$this->session->userdata('staff_user_id');	
                                        $this->db->where('user_id',$loginid); 
                                        $result=$this->db->get('tblleaveapplication')->result();
                                        $to = preg_replace("/[^0-9]/", "",$result[0]->duration);
                                        
                                        
                                        $count=count($result); 
                                       // echo $count;
                                  //  print_r($count);
                                         ?>
                                         
                                         <option <?php if($to >=$category['totalleave']) echo 'disabled'; ?> value="<?php echo  $category['leave_category_id']; ?>"><?php echo  $category['leave_category']; ?></option>
                                    <?php $i++;
                               
                                }?>
                                </select> 

                            </div>
                            <div class="col-sm-4"></div>
                            <div class="col-sm-8">
                                <div class="required" id="username_result"></div>
                            </div>
                        </div>
                        <div class="form-group">
                           <div class="row">
                            <label class="col-sm-4 control-label">Duration <span class="required"> *</span></label>
                            <div class="col-sm-8">
                                <label class="radio-inline c-radio">
                                    <input type="radio" name="leave_type" value="single_day" checked="" data-parsley-multiple="leave_type" data-parsley-id="7" >
                                    Single day</label>
                                <label class="radio-inline c-radio">
                                    <input type="radio" name="leave_type" value="multiple_days" data-parsley-multiple="leave_type">
                                   Multiple days</label>
                           <!--     <label class="radio-inline c-radio">
                                    <input type="radio" name="leave_type" value="hours" data-parsley-multiple="leave_type">
                                    Hours</label> -->
                            </div>
                          </div>
                        </div>



                        <div class="form-group" id="single_day">
                           <div class="row">
                            <label class="col-sm-4 control-label">Start Date 
                              <span class="required"> *</span></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <input type="text" name="single_day_start_date"  class="form-control datepicker" data-date-min-date="0" placeholder="Select A Date..">
                                    <div class="input-group-addon">
                                        <a href="#"><i class="fa fa-calendar"></i></a>
                                    </div>
                                </div>
                            </div>
                          </div>
                        </div>
                        <div id="multiple_days" style="display: none;">
                            <div class="form-group">
                                <label class="col-sm-4 control-label">Start Date 
                                  <span class="required"> *</span>
                                </label>
                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" name="multiple_days_start_date" id="start_date" class="form-control" placeholder="Select Start Date..">
                                        <div class="input-group-addon" >
                                            <a href="#"><i class="fa fa-calendar"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label">End Date <span class="required"> *</span></label>

                                <div class="col-sm-8">
                                    <div class="input-group">
                                        <input type="text" name="multiple_days_end_date" id="end_date"  class="form-control datepicker" value="" data-format="dd-mm-yyyy" data-parsley-id="17" placeholder="Select End Date..">
                                        <div class="input-group-addon">
                                            <a href="#"><i class="fa fa-calendar"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group" id="hours" style="display: none;">
                            <label class="col-sm-4 control-label">Start Date
                              <span class="required"> *</span></label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                    <input type="text" name="hours_start_date" id="hours_start_date"  class="form-control datepicker" value="" data-format="dd-mm-yyyy" data-parsley-id="19" placeholder="Select A Date..">
                                    <div class="input-group-addon">
                                        <a href="#"><i class="fa fa-calendar"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <label class="col-sm-5 control-label"> Hours                                    <span class="required"> *</span></label>
                                <div class="col-sm-7 pr0">
                                    <select name="hours" id="hours" class="form-control" data-parsley-id="21">
                                        <option value="1">01</option>
                                        <option value="2">02</option>
                                        <option value="3">03</option>
                                        <option value="4">04</option>
                                        <option value="5">05</option>
                                        <option value="6">06</option>
                                        <option value="7">07</option>
                                        <option value="8">08</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="field-1" class="col-sm-4 control-label">Reason</label>
                            <div class="col-sm-8"><textarea id="present" name="reason" class="form-control" rows="6" data-parsley-id="23"></textarea></div>
                        </div>

                        
                        <div class="form-group" style="margin-bottom: 0px">
                            <label for="field-1" class="col-sm-4 control-label">Attachment</label>

                            <div class="col-sm-8">
                               <input type="file" name="file" class="form-control">
                            </div>
                        </div>
                        <br/><br/>
                        <div class="form-group mt-lg">
                            <div class="col-sm-offset-4 col-sm-5">
                                <button type="submit" id="leave-save-button"  name="sbtn" value="1" class="btn btn-primary">Apply
                                </button>
                            </div>
                        </div>
                        <br>
                    </div>
                </form>
            </div>
                        <div class="col-md-4">
                         <div class="panel panel-custom">
                    <!-- Default panel contents -->
                    <div class="panel-heading">
                        <div class="panel-title">
                            <strong>My Leave Details</strong>
                        </div>
                    </div>
                   <table class="table">
                        <tbody>
                          <?php $total_quota=0; $total_Approveleave=0;  foreach($leaveCategory as $category1) { $catId=$category1['leave_category_id']; 
                            $this->db->where('leave_category_id',$catId); 
                            $this->db->where('application_status','2');
							$loginid=$this->session->userdata('staff_user_id');	
                            $this->db->where('user_id',$loginid); 
                            $result=$this->db->get('tblleaveapplication')->result(); 
                             $to = preg_replace("/[^0-9]/", "",$result[0]->duration);
                            // print_r($leaveCategory);
                            
                            
                            ?>
                               <tr>
                                    <td><strong> <?php echo  $category1['leave_category']; ?></strong>:</td>
                                    <td>
                                        <?php if($to == null){ echo "0"; } else { echo  $to; }  ?>/<?php echo  $category1['leave_quota']; ?></td>
                                </tr>
                          <?php

                           $total_Approveleave=$total_Approveleave+ $to;
                           $total_quota=$total_quota+$category1['leave_quota'];  

                           } ?>
                            <tr>
                              <td style="background-color: #e8e8e8; font-size: 14px; font-weight: bold;">
                                  <strong> Total</strong>:
                              </td>
                              <td style="background-color: #e8e8e8; font-size: 14px; font-weight: bold;"><?php echo  $total_Approveleave.' / '.$total_quota; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <!-- <button type="submit" class="btn btn-info">Save</button> -->
                </div>
            </div><!-- /.modal-content -->
          <!--   </form>   -->      

          </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


<script id="hidden-columns-table-leads" type="text/json">
   <?php echo get_staff_meta(get_staff_user_id(), 'hidden-columns-table-leads'); ?>
</script>
<?php include_once(APPPATH.'views/admin/leads/status.php'); ?>
<?php init_tail(); ?>
<script>

$('.radio-inline.c-radio input[type="radio"]').click(function(){
   
    if($(this).is(':checked'))
    {
      $val=$(this).val();
      if($val=='single_day')
      {
        $('#single_day').css('display','block'); 
        $('#multiple_days').css('display','none'); 
        $('#hours').css('display','none');  
      }
      if($val=='multiple_days')
      {
        $('#single_day').css('display','none'); 
        $('#multiple_days').css('display','block'); 
        $('#hours').css('display','none'); 
      }
      if($val=='hours')
      {
        $('#single_day').css('display','none'); 
        $('#multiple_days').css('display','none'); 
        $('#hours').css('display','block'); 
      }

    }
  });



 
 function leavesave()
 {
   var leave_category_id=$('#leave_category_id').val();
   var duration=$(".radio-inline.c-radio input[name='leave_type']:checked").val();
   var single_day_start_date=""; 
   var multiple_days_start_date="";
   var multiple_days_end_date="";
   var hours_start_date="";
   var hours=""; 
    
   if (duration) {
    
          switch(duration)
          {
             case 'single_day':
             single_day_start_date=$('#single_day_start_date').val();
             break;
                  
             case 'multiple_days':
               multiple_days_start_date=$('#multiple_days_start_date').val();
               multiple_days_end_date=$('#multiple_days_end_date').val();
             break;

             case 'hours':
             hours_start_date=$('#hours_start_date').val(); 
             hours=$('#hours').val(); 
             break;
          }
          
          //alert( leave_category_id+'--'+duration+'--'+single_day_start_date+'--'+multiple_days_start_date+'--'+multiple_days_end_date+'--'+hours_start_date+'--'+hours);

          var reason=$('#present').val();  
          var file=""; 

          $.ajax({
            url: "<?php echo base_url(); ?>admin/leave/saveleave", // Url to which the request is send
            type: "POST",             // Type of request to be send, called as method
            data: new FormData('#Save-leave-form'), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            success: function(data)   // A function to be called if request succeeds
            {

            //$('#loading').hide();
            // $("#message").html(data);
            }
            });

          


   }else{
  
     $('.alertmessage').html('<div class="text-danger">Plase first  select Leave Duration ..</div>'); 
   }

 }
 
 $('#Save-leave-form').submit(function(e){ 
      e.preventDefault(); 
 alert()
    var formURL = $('#Save-leave-form').attr("action");
    var formData = new FormData($('#Save-leave-form')[0]);

      $.ajax({
            url: "<?php echo base_url(); ?>admin/leave/saveleave", // Url to which the request is send
            //url:formURL, 
            type: "POST",             // Type of request to be send, called as method
            //data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            data:formData, 
            contentType: false,       // The content type used when sending data to the server.
            cache: false,             // To unable request pages to be cached
            processData:false,        // To send DOMDocument or non processed data file it is set to false
            success: function(data)   // A function to be called if request succeeds
            {
              //console.log(data); 
             if(data=='save')
             {
                $('#ticket-service-modal').modal('hide');
             }

            //$('#loading').hide();
            // $("#message").html(data);
            }
            });


       
 }); 


</script>

<script>
$(document).ready(function(){
    $("#txtFromDate").datepicker({
        numberOfMonths: 2,
        onSelect: function(selected) {
          $("#txtToDate").datepicker("option","minDate", selected)
        }
    });
    $("#txtToDate").datepicker({ 
        numberOfMonths: 2,
        onSelect: function(selected) {
           $("#txtFromDate").datepicker("option","maxDate", selected)
        }
    });  
});



</script>





</body>
</html>
