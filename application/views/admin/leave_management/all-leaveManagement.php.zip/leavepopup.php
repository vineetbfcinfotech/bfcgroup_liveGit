
         <?php
                                foreach($leavedata as $ld)
                                {
                                          $this->db->where('staffid',$ld->user_id); 
                                          $result=$this->db->get('tblstaff')->result();
                                ?>       <div class="modal-body">
                    <div class="row">
                         <div class="col-sm-8" style=" font-size: 18px;line-height: 37px;"><table>
                               
                               
                                    <tr><th style="width: 154px;" >Name</th><td ><?php echo  $result[0]->firstname.' '.$result[0]->lastname; ?></td></tr>
                                    <tr><th style="width: 154px;" >Applied On</th><td ><?php echo  $ld->application_date; ?></td></tr>
                                   
                                    <tr><th style="width: 154px;" >Type</th><td ><?php if( $ld->leave_type == "multiple_days"){ echo "Multiple Days"; } else { echo  "Single Day"; }  ?></td></tr>  
                                    <tr><th style="width: 154px;" >Start Date</th><td ><?php echo  $ld->leave_start_date; ?></td></tr>
                                    
                                    <tr><th style="width: 154px;" >Duration</th><td ><?php echo  $ld->duration; ?></td></tr>
                                    <tr><th style="width: 154px;" >Leave Category</th>
                                     <td> <?php $catId=$ld->leave_category_id;  $this->db->where('leave_category_id',$catId);  $category=$this->db->get('tblleavecategory')->result(); 
                                      if($category)
                                         {
                                          echo  $category[0]->leave_category; 
                                         } 
                                          ?></td>
                                          </tr>
                                    <tr><th style="width: 154px;" >Reason</th><td ><?php echo  $ld->reason; ?></td></tr>
                                   
                                  <td colspan="2">
                                        <?php if($ld->application_status=='1'){?>
                                          
                                           <button onclick="togglestatus(<?php echo $ld->leave_application_id; ?>,'2')" class="btn btn-success appstatus btn-icon">Approve</button>
                                 
                                         <button onclick="togglestatus(<?php echo $ld->leave_application_id; ?>,'3')" class="btn btn-danger appstatus btn-icon _delete">Reject</button>
                                     <?php 
                                        }else if($ld->application_status=='2'){?>
                                             <button  class="btn btn-success appstatus btn-icon">Approved</button>
                                        <?php }else{?>
                                           <button  class="btn btn-danger appstatus btn-icon _delete">Rejected</button>
                                      <?php }?>
                                        

                                       </td>
                                </table></div>
                            <div class="col-md-4" style="border: #000 !important;
    border-radius: 20%;
    background: #343;">
                         <div class="panel panel-custom">
                    <!-- Default panel contents -->
                    <div class="panel-heading">
                        <div class="panel-title">
                            
                            <strong><?php echo  $result[0]->firstname; ?>'s Leave Details</strong>
                        </div>
                    </div>
                    <table class="table">
                        <tbody>
                          <?php $total_quota=0; $total_Approveleave=0;  foreach($leaveCategory as $category) { $catId=$category['leave_category_id']; 
                            $this->db->where('leave_category_id',$catId); 
                            $this->db->where('application_status','2');
                            $loginid=$this->session->userdata('staff_user_id');						
                            $this->db->where('user_id',$ld->user_id); 
                            $result=$this->db->get('tblleaveapplication')->result(); 
                             $to = preg_replace("/[^0-9]/", "",$result[0]->duration);
                            // print_r($category);
                            
                            
                            ?>
                               <tr>
                                    <td><strong> <?php echo  $category['leave_category']; ?></strong>:</td>
                                    <td>
                                        <?php if($to == null){ echo "0"; } else { echo  $to; }  ?>/<?php echo  $category['totalleave']; ?></td>
                                </tr>
                          <?php

                           $total_Approveleave=$total_Approveleave+ $to;
                           $total_quota=$total_quota+$category['totalleave'];  

                           } ?>
                            <tr>
                              <td style="background-color: #e8e8e8; font-size: 14px; font-weight: bold;">
                                  <strong> Total</strong>:
                              </td>
                              <td style="background-color: #e8e8e8; font-size: 14px; font-weight: bold;"><?php echo  $total_Approveleave.' / '.$total_quota; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                        </div>
                    </div>
                </div>
                
                
                  <?php } ?>
<script>
function togglestatus(applicationId,status)
 {
     
     $.ajax({
        url: "<?php echo base_url(); ?>admin/leave/togglestatus", // Url to which the request is send
        type: "POST",             // Type of request to be send, called as method
        data: {AppId:applicationId,sts:status}, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
        success: function(data)   // A function to be called if request succeeds
        {
          //alert(data); 
          $("#rowid_"+applicationId+" .appstatus").html(data);
          alert(data); 
          if(data=='Approved')
          {
             $("#rowid_"+applicationId+" .appstatus").removeClass('btn-danger');
             $("#rowid_"+applicationId+" .appstatus").addClass('btn-success');
          }
          else
          {
            $("#rowid_"+applicationId+" .appstatus").removeClass('btn-success');
            $("#rowid_"+applicationId+" .appstatus").addClass('btn-danger');
          }
          //$('#application-Details-modal').modal('show');
        }
        });
   }
                               </script>

                         