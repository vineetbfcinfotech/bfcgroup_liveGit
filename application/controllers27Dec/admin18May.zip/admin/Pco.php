<?php
header('Content-Type: text/html; charset=utf-8');
defined('BASEPATH') or exit('No direct script access allowed'); 
class Pco extends Admin_controller{
    private $not_importable_leads_fields;
    public function __construct(){
        parent::__construct();
       
    }
    public function index($value='')
   {
       echo "string";
   }
    //Quotation list
    public function printing_quotation(){
        // print_r("test");exit;
        $data['title'] = "Pending Projects";
        $data['business'] = "";
          $this->db->from ( 'tblleads' );
		    $this->db->join ( 'chorus_asf', 'chorus_asf.lead_id = tblleads.id');
		    $this->db->where ( 'tblleads.print_quotation_status', 1);
		    $query = $this->db->get();
		     $data['all_data'] = $query->result();
		    
        $this->load->view('admin/pco/printing_quotation', $data);
}
   
   
    
}
      
     
       
