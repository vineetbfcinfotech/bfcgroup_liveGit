<?php
header('Content-Type: text/html; charset=utf-8');
defined('BASEPATH') or exit('No direct script access allowed'); 
class Digital_marketing extends Admin_controller{
    private $not_importable_leads_fields;
    public function __construct(){
        parent::__construct();
        $this->not_importable_leads_fields = do_action('not_importable_leads_fields', ['id', 'source', 'assigned', 'status', 'dateadded', 'last_status_change', 'addedfrom', 'leadorder', 'date_converted', 'lost', 'junk', 'is_imported_from_email_integration', 'email_integration_uid', 'is_public', 'dateassigned', 'client_id', 'lastcontact', 'last_lead_status', 'from_form_id', 'default_language', 'hash']);
        $this->load->model('leads_model');
        $this->load->model('product_model', 'pmodel');
        $this->load->model('departments_model', 'depart_model');
        $this->load->model('teams_model', 'teamsm');
        $this->load->model('leadsdata_model', 'leadsdata');
        $this->load->library("pagination");
        $this->load->helper('url');
        $this->load->library('excel');
        $this->load->library('pdf');
    }
    
    //project aquired function
    public function project_aquired(){
        $data['title'] = "Pending Projects";
        $data['business'] = "";
        $data['newproject_data'] = $this->db->get_where('tblleads',array('print_quotation_status'=>1,"dm_project_status" => 0,))->result();
        $this->load->view('admin/dm/pending_project', $data);
    }
    public function changeProjectStatus(){
        $project_id = $_POST['project_id'];
        $data['all_data'] = $this->db->get_where('tblleads',array('id',$project_id))->row();
       // print_r($data['all_data']->lead_sub_service);
       $sub_service = explode(", ",$data['all_data']->lead_sub_service);
        $i=0;
       foreach ($sub_service as $key => $value) {

                              $this->db->select('*');
                              $this->db->from('tblpackagesubservices');
                              $this->db->where('id', $value); 
                              $where = '(serviceid=29  or serviceid = 4 or serviceid = 13)';
                              $this->db->where($where);

                              $result = $this->db->get(); 
                               $result = $result->result();
                            
                              
                               if($result){
                                ++$i;                  
                               }
                            
                           }
                           // echo $i;
                           

        $data_array = array(
            "total_dm_report_counting"=>$i,
            "dm_project_status" => 1,
            "dm_takeup_date" => date('Y-m-d H:i:s'),
        );
        // $update = $this->proof_reader_modal->changeProjectStatus($project_id, $data);
        $this->db->where('id',$project_id);
        $this->db->update('tblleads',$data_array);

    }
    
    //project inprogress function
    public function inprogress_projects(){
        $data['title'] = "Inprogress Projects";
        $data['business'] = "";
        //$data['projects'] = $this->leadsdata->get_inprogress_Projects();
         $data['newproject_data'] = $this->db->get_where('tblleads',array('print_quotation_status'=>1,"dm_project_status" => 1,))->result();
        $this->load->view('admin/dm/inprogress_progress', $data);
    }
     public function pip($id)
     {
        // echo $id;
       $data['all_data'] = $this->db->get_where('tblleads',array('id'=>$id))->row();
      
       $data['sub_service'] = explode(", ",$data['all_data']->lead_sub_service);
   // print_r($data['sub_service']);
        $this->load->view('admin/dm/pip_project', $data);
         
     }
     public function upload_report(){
        $id = $_POST['hidden_id'];
        $sub_service_id = $_POST['sub_service_id'];
        $sub_service_name = $_POST['sub_service_name'];
  
         $filename = $_FILES['file']['name'];
            $ckeck_ms = $this->db->get_where('tblleads',array('id'=>$id))->row();
            if ($filename) {
                $filename = $ckeck_ms->lead_author_name.'_'.$filename;
                
              
                // if($ckeck_ms->lead_pr_ms_file){
                //     unlink('assets/digital_marketing/facebook_report/'.$ckeck_ms->lead_pr_ms_file);
                // }
            $location = "assets/digital_marketing/facebook_report/".$filename;
            $imageFileType = pathinfo($location,PATHINFO_EXTENSION);
            $imageFileType = strtolower($imageFileType);
            /* Valid extensions */
            $valid_extensions = array("pdf", "doc", "docx","csv");
            $response = 0;
            if(in_array(strtolower($imageFileType), $valid_extensions)) {
            if(move_uploaded_file($_FILES['file']['tmp_name'],$location)){
               $total_dm_report_counting = $ckeck_ms->total_dm_report_counting - 1;
             $response = $location;
             if ($total_dm_report_counting == 0) {
                $data_update = array(
                    'dm_end_date'=> date('Y-m-d H:i:s'),
                    'dm_project_status'=>2,
                    'total_dm_report_counting'=>$total_dm_report_counting
             );  
             }else{
                $data_update = array(
                    'total_dm_report_counting'=>$total_dm_report_counting
             );
             }
             
                     $this->db->where('id',$id);
                     $this->db->update('tblleads',$data_update);
             $data_array = array(
                    'lead_id'=>$id,
                    'sub_service_id'=>$sub_service_id,
                    'sub_service_name'=>$sub_service_name,
                    'upload_report'=>$filename,
                );
                $this->db->insert('upload_dm_report_table',$data_array);
               set_alert('success', _l('Report uploaded successfully...'));
               if ($total_dm_report_counting == 0) {
        redirect('admin/Digital_marketing/completed_projects');
                  
               }else{
        redirect($_SERVER['HTTP_REFERER']);

               }

            }
            }else{
              set_alert('warning', _l('Please select valid file.'));
                redirect($_SERVER['HTTP_REFERER']);  
            }
           }else{
              set_alert('danger', _l('Please select a file.'));
                redirect($_SERVER['HTTP_REFERER']);  
            }
    }
    
    //completed projects function
    public function completed_projects(){
        
        $data['title'] = "Approved Projects";
        $data['project_data'] = $this->db->get_where('tblleads',array('print_quotation_status'=>1,"dm_project_status" => 2,))->result();
        $this->load->view('admin/dm/completed_project', $data);
    }
    public function bfcPublications(){
        $data['title'] = "BFC Publications";
        //$data['projects'] = $this->leadsdata->getCompletedProjects();
        $this->load->view('admin/dm/bfcPublications', $data);
    }
    public function bfcCapital(){
        $data['title'] = "BFC Capital";
        //$data['projects'] = $this->leadsdata->getCompletedProjects();
        $this->load->view('admin/dm/bfcCapital', $data);
    }
    public function bfcInfotech(){
        $data['title'] = "BFC Infotech";
        //$data['projects'] = $this->leadsdata->getCompletedProjects();
        $this->load->view('admin/dm/bfcInfotech', $data);
    }
   
    
}
      
     
       
