<?php
header('Content-Type: text/html; charset=utf-8');
defined('BASEPATH') or exit('No direct script access allowed'); 
class ProjectCordinatorDashboard extends Admin_controller{
	public function __construct(){
	    parent::__construct();
	    $this->load->model('Project_Cordinator_Dashboard_modal');
	}
	
	/* =========  Add Service Page Code Like =========
	            - add service view page code (Using this function add_service())
	            - save data from add service page code (Using this function save_service())
            	- list all services page code (Using this function list_service())
            	- edit service page code 
            	- update service page code (Using this function update_service())
            	- delete service page code (Using this function delete_service())
	
	*/
	
	// Show Add Services View Page
	public function add_service(){
	    $data['title'] = "Add Service";
	    $this->load->view('admin/Project_Cordinator/add_service', $data);
	}
	// Save service paga data
	public function save_service(){
        $data = array(
            		"packageid" => $_POST['package'],
            		"service_name" => $_POST['Service'],
            		);
        $added = $this->Project_Cordinator_Dashboard_modal->save_service($data);
	}
	// Update Service View Page
	public function update_service(){
	    $serviceId = $_POST['serviceId'];
        $data = array(
            "packageid" => $_POST['packageId'],
            "service_name" => $_POST['serviceName'],
        );
        $update = $this->Project_Cordinator_Dashboard_modal->update_service($serviceId,$data);
        if($update){
            redirect('admin/ProjectCordinatorDashboard/list_service'); 
        }else{
            echo "fails";
        }
        
	}
	// Get Service List
	public function get_service_list(){
        $package_id = $_POST['package_id']; 
        $added = $this->Project_Cordinator_Dashboard_modal->get_service_list($package_id);
	}
	// List All Services
	public function list_service(){
        $data['title'] = "Add Service";
        $data['services']= $this->db->select('*')->get('tblpackageservices')->result();
        $this->load->view('admin/Project_Cordinator/list_service', $data);
	}
	//Delete single service accoding to id
	public function delete_service(){
	    $serviceId = $_POST['serviceId']; 
        $added = $this->Project_Cordinator_Dashboard_modal->delete_service($serviceId);
	}
	
	
		/* =========  Add Sub Service Page Code Like =========
	            - add service view page code (Using this function add_subService())
	            - save data from add service page code (Using this function save_subService())
            	- list all services page code (Using this function list_subService())
            	- edit service page code 
            	- update service page code (Using this function update_subService())
            	- delete service page code (Using this function delete_subService())
	
	*/
		// Show Add Services View Page
	public function add_subservice(){
	    $data['title'] = "Add SubService";
	    $data['subservice']=$this->db->select('id,service_name')->get('tblpackageservices')->result();
	    $this->load->view('admin/Project_Cordinator/add_subservice', $data);
	}
	// Save service paga data
	public function save_subservicedata(){
        $data = array(
            		"cost" => $_POST['cost'],
            		"subservice_name" => $_POST['subServiceName'],
            		"subServiceNameValue" => $_POST['subServiceNameValue'],
            		"package_value" => $_POST['packageType'],
            		"book_type" => $_POST['bookType'],
            		"serviceid" => $_POST['Service'],
            		"packageid" => $_POST['Package'],
            		);
            		
        //print_r($data);exit;    		
        $added = $this->Project_Cordinator_Dashboard_modal->save_subservice($data);
        if($added){
            redirect('admin/ProjectCordinatorDashboard/add_subservice'); 
        }else{
            echo "fails";
        }
	}
	// List All subServices
	public function subservice_list(){
	    $data['title'] = "List Sub Service";
	    $this->db->select('tss.*,ts.service_name ');
        $this->db->join('tblpackageservices as ts', 'tss.serviceid=ts.id');
        $data['subservices']=$this->db->get('tblpackagesubservices as tss')->result();
        $this->load->view('admin/Project_Cordinator/list_subservices', $data);
	}
	// Update subService View Page
	public function update_subservice(){
	   
	   $subserviceId=$_POST['subserviceId'];
        $data = array(
            
            "packageid"=>$_POST['Package'],
            "serviceid"=>$_POST['service'],
            "book_type"=>$_POST['bookType'],
            "package_value"=>$_POST['packageType'],
            "subservice_name" => $_POST['subserviceName'],
            "cost" => $_POST['cost'],
        );
        //print_r($data);
        //exit;
        $update = $this->Project_Cordinator_Dashboard_modal->update_subservice($subserviceId,$data);
        if($update){
            redirect('admin/ProjectCordinatorDashboard/subservice_list'); 
        }else{
            echo "fails";
        }
        
	}
	//Delete single subservice accoding to id
	public function delete_subservice(){
	    $serviceId = $_POST['serviceId']; 
        $added = $this->Project_Cordinator_Dashboard_modal->delete_subservice($serviceId);
	}
	//Get services based on package id
	public function get_service(){
        $serviceId = $_POST['serviceId']; 
        $added = $this->Project_Cordinator_Dashboard_modal->get_services($serviceId);
        echo json_encode($added);
	}
	
	// Edit page View
	public function edit_subservice(){
        $subserviceId = end($this->uri->segment_array());
        $data['title'] = "Add Service";
        $this->db->where('id', $subserviceId);
        $this->db->select('*');
        $result = $this->db->get('tblpackagesubservices')->result();
        $data['subservice']=$result;
        $serviceId = $result[0]->packageid;
        
        $this->db->where('packageid', $serviceId);
        $this->db->select('*');
        $result1 =$this->db->get('tblpackageservices')->result();
        //print_r($resul1);exit;
        $data['subservicelist']=$result1;
        
        $this->load->view('admin/Project_Cordinator/edit_subservice', $data); 
	}
	

}


