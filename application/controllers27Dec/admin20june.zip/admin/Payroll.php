<?php
header('Content-Type: text/html; charset=utf-8');
defined('BASEPATH') or exit('No direct script access allowed');

use Dompdf\Dompdf;

class Payroll extends Admin_controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('payroll_model');
        $this->load->model('roles_model');
    }

    public function salary_template($id = null)
    {

        if (!empty($id)) {


            $data['active'] = 2;
        } else {
            $data['active'] = 1;
        }
        $data['title'] = _l('salary_template_details');


        $this->payroll_model->_table_name = "tbl_salary_template"; // table name
        $this->payroll_model->_order_by = "salary_template_id"; // $id
        $data['roles'] = $this->roles_model->get();
        $data['all_salary_template'] = $this->payroll_model->get();


        $this->load->view('admin/payroll/salary_template', $data);
    }

    public function manage_salary($id = null)
    {  
        if (!empty($id)) {
            
            
            $sal_id = $this->uri->segment(4);
            
            $this->db->select('tbl_salary_template.*');
            $this->db->where('salary_template_id', $sal_id);
            $data['staffsal'] = $this->db->get('tbl_salary_template')->row();
           // print_r($data['staffsal']);
            $to = $data['staffsal']->period_to;
            $from = $data['staffsal']->period_from;
            $staffid =  $data['staffsal']->salary_grade;
            
            $this->db->select_sum('net_credit');
            $this->db->where('converted_by', $staffid);
            $this->db->where('transaction_date >=', $from);
            $this->db->where('transaction_date <=', $to);
            $data['creditscore'] =  $this->db->get('tblbusiness')->result();
            
            $this->db->select('baby_sitting_loss');
            $this->db->where('staff_id', $staffid);
            $this->db->where('finacial_year', 2018);
            $data['bsl'] =  $this->db->get('tblincentive')->result();
            //print_r($this->db->last_query());
            
            //print_r($data['bsl']);
            $this->db->where('sal_temp_id', $staffid);
            $this->db->order_by("id", "asc");
             $data['salary_wef'] = $this->db->get('tbl_salary_wef')->result();
            
            
            $data['allemployee'] = $this->db->query("SELECT CONCAT(tblstaff.firstname,' ', tblstaff.lastname)as name, tblstaff.staffid as staffid  from tblstaff WHERE `staffid` = $staffid ")->row();
           
            $data['title'] = "Edit Salary Template";
            $this->load->view('admin/payroll/editsalary', $data);
        } else {
            $data['allemployee'] = $this->db->query("SELECT CONCAT(tblstaff.firstname,' ', tblstaff.lastname)as name, tblstaff.staffid as staffid  from tblstaff ORDER BY `staffid` ASC ")->result();
            $data['disabledempids'] = $this->db->query("SELECT GROUP_CONCAT(salary_grade) as staffid from tbl_salary_template ORDER BY `staffid` ASC ")->row()->staffid;
            $data['title'] = _l('salary_template_details');
            $this->load->view('admin/payroll/manage_salary', $data);
        }

    }
    
    public function editempsal()
    {
        if($this->input->post())
            {
            $userid = $_POST['staffid'];
            $basic_salary = $_POST['basic_salary'];
            $overtime_salary = $_POST['overtime_salary'];
            $house_rent_allowance = $_POST['house_rent_allowance'];
            $special_allowance = $_POST['special_allowance'];
            $conveyance_allowance = $_POST['conveyance_allowance'];
            $provident_fund = $_POST['provident_fund'];
            $tax_deduction = $_POST['tax_deduction'];
            $net_salary = $_POST['net_salary_emp'];
            $period_to = $_POST['enddate'];
            $period_from = $_POST['startdate'];
            $annual_sal = $_POST['annual_ctc'];
            $ctc_factor = $_POST['annual_per'];
            $ex_annual_ctc = $_POST['ex_annual_ctc'];
            $direct_cost = $_POST['direct_cost'];
            $bep = $_POST['bep'];
            $monthy_sal = $_POST['price'];
            $q_ctc = $_POST['qualifying_ctc'];
            $start_date_wef = $_POST['start_date_wef'];
            $ctc_sal_factor =  $_POST['annual_per'];
            
            
            $resultData1 = array('basic_salary' => $basic_salary, 'direct_cost' => $direct_cost, 'bep' => $bep,
            'period_to' => $period_to, 'period_from' => $period_from, 'annual_sal' => $annual_sal, 'ctc_factor' => $ctc_factor, 'exp_annual_ctc' => $ex_annual_ctc,
            'overtime_salary' => $overtime_salary, 'house_rent_allowance' => $house_rent_allowance, 'special_allowance' => $special_allowance, 'conveyance_allowance' => $conveyance_allowance, 'provident_fund' => $provident_fund, 'tax_deduction' => $tax_deduction, 'net_salary' => $net_salary);
           
           
            
            $this->db->where('salary_grade', $userid);
            $this->db->update('tbl_salary_template', $resultData1);
            
            $this->db->select('timefrom, id');
            $this->db->where(array('sal_temp_id' => $userid));
            $this->db->order_by("id", "desc");
            $query = $this->db->get('tbl_salary_wef');
            //$checkdate = $query->num_rows();
            $wefresult = $query->result();
            
           
            
            
            if ($wefresult[0]->timefrom == $start_date_wef) {
                
               // echo $wefresult[0]->timefrom;
                $wef_data = array('monthly' => $monthy_sal, 'ctc_factor' => $ctc_sal_factor, 'q_ctc' => $q_ctc, 'timefrom' => $start_date_wef, 'timeto' => $period_to);
            $this->db->where('sal_temp_id', $userid);
            $this->db->where('timefrom', $start_date_wef);
            $this->db->update('tbl_salary_wef', $wef_data);
            
            set_alert('success', 'Salary Updated Successfully');
            redirect(base_url('admin/payroll/salary_template'));
            } 
            else
            {
                if($wefresult[0]->timefrom != null)
                {
                    $lastwefid= $wefresult[0]->id;
                    $timeto = $wefresult[0]->timefrom;
                   /* $lastwefdate = $start_date_wef;
                    $lastwefdate = date('Y-m-d', strtotime($stop_date . ' -1 day'));*/
                    $lastwefdate = new DateTime($start_date_wef);

                  $lastwefdate=   $lastwefdate->modify('-1 day');
                  $lastwefdate=   $lastwefdate->format('Y-m-d');
                    
                    $updatetimeto = array('timeto' => $lastwefdate);
                    $this->db->where('id', $lastwefid);
                    $this->db->update('tbl_salary_wef', $updatetimeto);
                    
                    
                    
                }
               
                
                $wef_data = array('sal_temp_id' => $userid, 'monthly' => $monthy_sal, 'ctc_factor' => $ctc_sal_factor, 'q_ctc' => $q_ctc, 'timefrom' => $start_date_wef, 'timeto' => $period_to);
                $this->db->insert('tbl_salary_wef', $wef_data);
                set_alert('success', 'Salary WEF Updated Successfully');
            redirect($_SERVER['HTTP_REFERER']);
            }
            
            
            
            /*$staff_id = $userid;
            $financial_year = $this->input->post('finacial_year', TRUE);
            $ctc = $ex_annual_ctc;
            
            $qualifying_ctc  = $this->input->post('qualifying_ctc', TRUE);
            $credit_score_fy = $this->input->post('credit_score_fy', TRUE);
            $cs_per_qctc = $this->input->post('cs_per_qctc', TRUE);
            $pl_over_ctc = $this->input->post('pl_over_ctc', TRUE);
            $rm_incentive_fy = $this->input->post('payment_amount1', TRUE);
            $bbsht = $pl_over_ctc;
            $baby_shitiing_loss = preg_replace("/&#?[a-z0-9]{2,8};/i","",$bbsht); 
            
            
            $this->db->select('staff_id');
            $this->db->where(array('tt.staff_id' => $staff_id, 'tt.finacial_year' => $financial_year ));
            $query = $this->db->get('tblincentive tt');
            $checkdate = $query->num_rows();
            if ($checkdate > 0) {
                set_alert('warning', "Staff Incentive Already Defined For $financial_year ");
                redirect($_SERVER['HTTP_REFERER']);
            } 
           
            
            
            
            $resultData = array('staff_id' => $staff_id, 'period_to' => $period_to, 'period_from' => $period_from, 'ctc' => $ctc, 'baby_sitting_loss' => $baby_shitiing_loss, 'qualifying_ctc' => $qualifying_ctc, 'credit_score_fy' => $credit_score_fy, 'cs_per_qctc' => $cs_per_qctc, 'pl_over_ctc' =>$pl_over_ctc, 'rm_incentive_fy' => $rm_incentive_fy );
            
            
            
            $this->db->insert('tblincentive', $resultData);*/
    
            /*set_alert('success', 'Salary Updated Successfully');
            redirect(base_url('admin/payroll/salary_template'));*/
            }
    }
    
    public function deletesaltem()
    {
        $sal_id = $this->uri->segment(4);
        

           $success = $this->payroll_model->deletesaltem($sal_id);

           set_alert('success', _l('deleted', "Salary Template"));

           redirect($_SERVER['HTTP_REFERER']);
    }

    public function set_salary_details()
    {

        $userid = $_POST['salary_grade'];
        $basic_salary = $_POST['basic_salary'];
        $overtime_salary = $_POST['overtime_salary'];
        $house_rent_allowance = $_POST['house_rent_allowance'];
        $special_allowance = $_POST['special_allowance'];
        $conveyance_allowance = $_POST['conveyance_allowance'];
        $provident_fund = $_POST['provident_fund'];
        $tax_deduction = $_POST['tax_deduction'];
        $net_salary = $_POST['net_salary_emp'];
        
            $period_to = $_POST['enddate'];
            $period_from = $_POST['startdate'];
            $annual_sal = $_POST['annual_ctc'];
            $ctc_factor = $_POST['annual_per'];
            $ex_annual_ctc = $_POST['ex_annual_ctc'];
            $direct_cost = $_POST['direct_cost'];
            $bep = $_POST['bep'];
            $qualifying_ctc = $_POST['qualifying_ctc'];


        $resultData = array( 'direct_cost' => $direct_cost, 'bep' => $bep,'period_to' => $period_to, 'period_from' => $period_from, 'annual_sal' => $annual_sal, 'ctc_factor' => $ctc_factor, 'exp_annual_ctc' => $ex_annual_ctc,'salary_grade' => $userid, 'basic_salary' => $basic_salary, 'overtime_salary' => $overtime_salary, 'house_rent_allowance' => $house_rent_allowance, 'special_allowance' => $special_allowance, 'conveyance_allowance' => $conveyance_allowance, 'provident_fund' => $provident_fund, 'tax_deduction' => $tax_deduction, 'net_salary' => $net_salary);
        // print_r($resultData);
        //  exit;
        $this->db->insert('tbl_salary_template', $resultData);
        $wef_data = array('sal_temp_id' => $userid, 'monthly' => $net_salary, 'ctc_factor' => $ctc_factor, 'q_ctc' => $qualifying_ctc, 'timefrom' => $period_from, 'timeto' => $period_to);
                $this->db->insert('tbl_salary_wef', $wef_data);

        set_alert('success', 'Salary Added Successfully');
        redirect(base_url('admin/payroll/manage_salary'));
    }

    public function salary_report()
    {
        $data['title'] = _l('salary_report');
        $data['staff_members'] = $this->staff_model->get('', ['active' => 1]);


        $subview = 'salary_report';

        $this->load->view('admin/payroll/' . $subview, $data);
    }

    public function get_salary_report()
    {
        $staff_id = $this->input->post('staff_id', TRUE);
        $this->db->select('bio_id');
        $this->db->where('staffid',$staff_id);
        $staff_bio = $this->db->get('tblstaff')->row();
        $staff_bio_id = $staff_bio->bio_id;
        $date = explode('-', $this->input->post('date', TRUE));
        $month = $date[0];
        $year = $date[1];
        $data['tmonth'] = $month . "-" . $year;
        $dayinmonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        /*Sunday Calculation in current Month */
        $monthName = date("F", mktime(0, 0, 0, $month));
        $fromdt = date('Y-m-01 ', strtotime("First Day Of  $monthName $year"));
        $todt = date('Y-m-d ', strtotime("Last Day of $monthName $year"));

        $num_sundays = '';
        for ($i = 0; $i <= ((strtotime($todt) - strtotime($fromdt)) / 86400); $i++) {
            if (date('l', strtotime($fromdt) + ($i * 86400)) == 'Sunday') {
                $num_sundays++;
            }
        }

        $totalsunday = $num_sundays;


        /* End of Sunday Calculation*/

        /*Holiday in month start*/
        $this->db->select_sum('days');
        $this->db->where(array('month(quota)' => $month, 'year(quota)' => $year));
        $hlday_inmth = $this->db->get('tblholidays')->row();
        $holi_month = $hlday_inmth->days;


        /*echo $holi_month;
       
        exit;*/
        /*Holiday in month end*/
        if ($holi_month > 0) {
            //$newdayinmonth = $dayinmonth + $holi_month;
            $num = $dayinmonth - ($totalsunday + $holi_month);

        } else {
            $num = $dayinmonth - $totalsunday;
        }
        $this->db->select('net_salary');
        $this->db->where(array('salary_grade' => $staff_id));
        $staffsal = $this->db->get('tbl_salary_template')->result_array();
        $staffnetsal = $staffsal[0]['net_salary'];

        $monthpds = $staffnetsal / $num;

        
        $tableatt = "deviceLogs_1_2020";
        if (!empty($staff_id)) {
            $this->db->select('*');
            $this->db->where(array('UserId' => $staff_bio_id, 'month(LogDate)' => $month, 'year(LogDate)' => $year));
            //$this->db->where($where);
            $this->db->group_by("date(LogDate)");
            $salarydays = $this->db->get($tableatt)->num_rows();
            $this->db->select('*,CONCAT(firstname," ",lastname) as full_name');
            $this->db->where(array('staffid' => $staff_id));
            $data['employee'] = $this->db->get('tblstaff')->result_array();
            $data['staff_members'] = $this->staff_model->get('', ['active' => 1]);
            $this->db->select('*');
            $this->db->where(array('UserId' => $staff_bio_id, 'month(LogDate)' => $month));
            $this->db->group_by("date(LogDate)");
            $data['nworking'] = $this->db->get($tableatt)->num_rows();
            $this->db->select('*');
            $this->db->where(array('UserId' => $staff_bio_id, 'month(LogDate)' => $month, 'year(LogDate)' => $year));
            $this->db->group_by("date(LogDate)");
            $data['nleave'] = $this->db->get($tableatt)->num_rows();
            $data['monthsal'] = $monthpds * $salarydays;


        }

        $data['title'] = _l('salary_report');
        $this->load->view('admin/payroll/salary_report', $data);
    }

    public function make_payment($id = "")
    {
        if (!empty($id)) {


            $staff_id = $this->uri->segment(4);
            $date = explode('-', $this->uri->segment(5));
            $month = $date[0];
            $year = $date[1];
            $data['tmonth1'] = $year . "-" . $month;
            $data['employeesal'] = $this->payroll_model->getemployeesal($staff_id);
            $data['monthsal'] = $this->uri->segment(6);

            /*print_r($data['employeesal']);
            exit;*/


        } else {

        }
        $data['salary_payment_info'] = $this->payroll_model->getpaymenthistory($staff_id);
        /*print_r($data['salary_payment_info']);
        exit;*/
        $data['employeedetails'] = $this->payroll_model->employeedetails($staff_id);
        $data['title'] = _l('salary_template_details');
        $this->load->view('admin/payroll/make_payment', $data);
    }

    public function get_payment()
    {

        $staff_id = $this->input->post('staffid', TRUE);
        $payment_month = $this->input->post('payment_month', TRUE);
        $fine_deduction = $this->input->post('fine_deduction', TRUE);
        $fine_deduction_comment = $this->input->post('fine_deduction_comment', TRUE);
        $payment_type = $this->input->post('payment_type', TRUE);
        $comments = $this->input->post('comments', TRUE);
        $paid_date = date('Y-m-d');
        $gross_salary = $this->input->post('gross_salary', TRUE);
        $net_salary = $this->input->post('net_salary', TRUE);
        $amount = $this->input->post('payment_amount', TRUE);

        $resultData = array('user_id' => $staff_id, 'payment_month' => $payment_month, 'fine_deduction' => $fine_deduction, 'fine_deduction_comment' => $fine_deduction_comment, 'payment_type' => $payment_type, 'comments' => $comments, 'paid_date' => $paid_date, 'gross_salary' => $gross_salary, 'net_salary' => $net_salary, 'amount' => $amount);
        /*print_r($resultData);
        exit;*/
        $this->db->insert(' tbl_salary_payment', $resultData);

        set_alert('success', 'Salary Issued Successfully');
        redirect($_SERVER['HTTP_REFERER']);
    }

    public function generate_payslip($id = '', $pdf = '')
    {
        $salary_payment_id = $this->uri->segment(4);
        $data['id'] = $salary_payment_id;
        $data['salary_payment_info'] = $this->payroll_model->getpaymenthistory($salary_payment_id);
        $staff_id = $data['salary_payment_info'][0]->user_id;
        $data['employeedetails'] = $this->payroll_model->employeedetails($staff_id);
        $data['employeesal'] = $this->payroll_model->getemployeesal($staff_id);
        $data['title'] = _l('salary_report');
        if (!empty($pdf)) {
            $html = $this->load->view('admin/payroll/salary_slip', $data, true);
            $dompdf = new Dompdf();
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->set_option('defaultFont', 'Courier');
            $dompdf->set_option('isHtml5ParserEnabled', true);
            $dompdf->set_option('isRemoteEnabled', true);
            $dompdf->render();
            $dompdf->stream();
            //$pdf = $dompdf->output();
        } else {
            $this->load->view('admin/payroll/generate_payslip', $data);
        }
    }

    function test()
    {

        $html = "<html><body>hello</body></html>";
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->set_option('defaultFont', 'Courier');
        $dompdf->set_option('isHtml5ParserEnabled', true);
        $dompdf->set_option('isRemoteEnabled', true);
        $dompdf->render();
        $dompdf->stream();
        $pdf = $dompdf->output();
    }

    function salary_payment_details_pdf()
    {

    }
    
    public function incentive_select()
    {
        $data['title'] = "Select Designation For Incentive Calculation";
        $data['staff_members'] = $this->staff_model->get('', ['active' => 1]);
        $this->payroll_model->_table_name = "tbl_salary_template"; // table name
        $this->payroll_model->_order_by = "salary_template_id"; // $id
        $data['roles'] = $this->roles_model->get();
        $data['all_salary_template'] = $this->payroll_model->get_incen();
         


        
        $this->load->view('admin/payroll/incentive_select', $data);
    }
    
    public function define_incentive()
    {
        $data['title'] = "View / Define Incentive ";
        $staff_id = $this->uri->segment(4);
        //echo $staff_id;
        $data['employeedetails'] = $this->payroll_model->employeedetails($staff_id);
        $data['employeesal'] = $this->payroll_model->getemployeesal($staff_id);
        $this->db->select_sum('net_credit');
        $this->db->where('converted_by', $staff_id);
        $data['creditscore'] =  $this->db->get('tblbusiness')->result();
        $data['incentive_payment_info'] = $this->payroll_model->getincentivehistory($staff_id);
        //print_r($this->db->last_query());
        //print_r($data['incentive_payment_info']);
        $this->load->view('admin/payroll/define_incentive', $data);
    }
    
    function save_incentive()
    {
        $staff_id = $this->input->post('staffid', TRUE);
        $financial_year = $this->input->post('finacial_year', TRUE);
        $ctc = $this->input->post('exp_annual_ctc', TRUE);
        $baby_shitiing_loss = $this->input->post('baby_shitiing_loss', TRUE);
        $qualifying_ctc  = $this->input->post('qualifying_ctc', TRUE);
        $credit_score_fy = $this->input->post('credit_score_fy', TRUE);
        $cs_per_qctc = $this->input->post('cs_per_qctc', TRUE);
        $pl_over_ctc = $this->input->post('pl_over_ctc', TRUE);
        $rm_incentive_fy = $this->input->post('payment_amount1', TRUE);
        
        
        $this->db->select('staff_id');
        $this->db->where(array('tt.staff_id' => $staff_id, 'tt.finacial_year' => $financial_year ));
        $query = $this->db->get('tblincentive tt');
        $checkdate = $query->num_rows();
        if ($checkdate > 0) {
            set_alert('warning', "Staff Incentive Already Defined For $financial_year ");
            redirect($_SERVER['HTTP_REFERER']);
        } 
       
        
        
        
        $resultData = array('staff_id' => $staff_id, 'finacial_year' => $financial_year, 'ctc' => $ctc, 'baby_sitting_loss' => $baby_shitiing_loss, 'qualifying_ctc' => $qualifying_ctc, 'credit_score_fy' => $credit_score_fy, 'cs_per_qctc' => $cs_per_qctc, 'pl_over_ctc' =>$pl_over_ctc, 'rm_incentive_fy' => $rm_incentive_fy );
        
        
        
        $this->db->insert('tblincentive', $resultData);

        set_alert('success', 'Incentive Added Successfully ');
        redirect($_SERVER['HTTP_REFERER']);
    }
    
    public function deleteincentive()
    {
        $id = $this->uri->segment(4);
        

           $success = $this->payroll_model->deleteincentive($id);

           set_alert('success', _l('deleted', "Incentive"));

           redirect($_SERVER['HTTP_REFERER']);
    }
    
    public function incentive_report()
    {
        $data['title'] = "Incentive Report ";
        $data['bodyclass'] = 'hide-sidebar';
        $data['rmconverted'] = $this->payroll_model->rmconverted();
        $data['incentive_payment_info'] = $this->payroll_model->get_incen();
        
        $this->load->view('admin/payroll/incentive_report', $data);
    }
    
    function custom_incentive_filter()
    {
        
        $leads = $this->payroll_model->get_bussiness_filter();
        $transctiondatestart = $_GET['datestart'];
        $transctiondateend = $_GET['dateend'];
        
        ;
        $this->printBussinessData($leads, $transctiondatestart,$transctiondateend); 
    }
    
        private function printBussinessData($leads,$transctiondatestart,$transctiondateend)
    {
         if (!empty($leads)) { ?>
                            <table name="incentive_report"  id="incentive_report" class="table dt-table scroll-responsive">
                                <thead>
                                <tr>
                                    <th><?php echo _l('id'); ?></th>
                                    <th class="bold">Staff Name</th>
                                    <th class="bold">Finacial Year</th>
                                    <th class="bold">BEP</th>
                                    <th class="bold">Baby Sitting Loss</th>
                                    <th class="bold">Qualifying CTC</th>
                                    <th class="bold">Credit score</th>
                                    <th class="bold">Credit score as % of QCTC</th>
                                    <th class="bold">P/L over QCTC</th>
                                    <th class="bold">RM's Incentive for the FY</th>
                                    <!--<th class="bold">TLs' incentive for the FY</th>
                                    <th class="bold">GL's Bonus for the FY</th>-->
                                </tr>
                                </thead>
                                <tbody class="">
                                <?php 
                                $leave_start = DateTime::createFromFormat('Y-m-d', $transctiondatestart);
                                $leave_end = DateTime::createFromFormat('Y-m-d', $transctiondateend);
                                $customdate = $leave_end->diff($leave_start)->format("%a")+1;
                                 foreach ($leads as $alllead) {
                                   
                                    ?>
                                    <tr>
                                        <td><?= @++$i; ?></td>
                                        <td> <?= $alllead->firstname; ?>
                                        </td>
                                        <td>
                                            <?php  
                                            $fin_start = $alllead->period_from;
                                            $fin_end = $alllead->period_to;
                                            
                                            $leave_start = DateTime::createFromFormat('Y-m-d', $fin_start);
                                            $leave_end = DateTime::createFromFormat('Y-m-d', $fin_end);
                                            $diffDays = $leave_end->diff($leave_start)->format("%a");
                                            $onedaybep = $alllead->bep/$diffDays;
                                            ?>
                                            
                                            
                                            
                                            <?= $alllead->period_to; ?></td>
                                        <td for="bep"> <?= number_format($onedaybep*$customdate, 2, '.', ''); ?></td>
                                        <td for="baby_shitiing_loss">0
                                        </td>
                                        <td><?= $alllead->qualifying_ctc; ?>  </td>
                                        <td>
                                        <?php
                                        $this->db->select_sum('net_credit');
                                        $this->db->where('converted_by', $alllead->salary_grade);
                                        $this->db->where('status', "Verified");
                                        $this->db->where('transaction_date >=', $transctiondatestart);
                                        $this->db->where('transaction_date <=', $transctiondateend);
                                        $creditscore =  $this->db->get('tblbusiness')->result();
                                        ?>
                                        <?= number_format($creditscore[0]->net_credit, 2, '.', ''); ?>
                                        </td>
                                        <td> </td>
                                        <td class="pl_over"><?= $alllead->pl_over_ctc; ?></td>
                                        <td><b><?= $alllead->rm_incentive_fy; ?></b></td>
                                        <!--<td><?= $alllead->tl_incentive_fy; ?></td>
                                        <td><?= $alllead->gl_incentive_fy; ?></td>-->
                                    </tr>
                                    <?php 
                                
                                $totbep = $totbep + (number_format($onedaybep*$customdate, 2, '.', ''));
                                $tocredit = $tocredit +  number_format($creditscore[0]->net_credit, 2, '.', '');
                                        }

                                        $totalbep = $totbep;
                                        $totalcredit = $tocredit;
                                        ?>
                                        <tr>
                                    <th ></th>
                                    <th ></th>
                                    <th ></th>
                                    <th style="font-weight: bold;"><span id="sum_bep_amount">Total BEP: Rs. <?php echo $totalbep; ?></span></th>
									<th ></th>
									<th ></th>
                                    <th style="font-weight: bold;"><span id= "sum_credit_amount">Net Credit: Rs. <?php echo $totalcredit; ?></span></th>
									<th ></th>
									<th ></th>
									
                                    
									<th ></th>
									<th ></th>
                                    <th ></th>
									<th ></th>
								
								</tr>
                                    <script>
    $(document).ready(function() {
    $('.pl_over:contains("-")').css('color', 'red');
  $('.status:contains("Received")').css('color', 'green'); 
});
</script>

<script>

    var table = document.getElementById("incentive_report");
    
    for (var i = 1; i < table.rows.length; i++) {
   var firstCol = table.rows[i].cells[3]; //first column
    console.log(firstCol.innerHTML);
    
    
        
        var exp_annual_ctc = table.rows[i].cells[3].innerHTML;
         var   baby_shitiing_loss = table.rows[i].cells[4].innerHTML;
          var expctc = parseFloat(exp_annual_ctc.replace(",", ""));
          var   credit_score = table.rows[i].cells[6].innerHTML;
          var credit_score_fy = parseFloat(credit_score.replace(",", ""));  
          bbys = parseFloat(baby_shitiing_loss);
          
          //alert(bbys);
            calcPrice = expctc + bbys;
            
            discountPrice = calcPrice.toFixed(2);
            
            //alert(credit_score_fy);
            
            percentagediff = credit_score_fy - discountPrice;
            
            percentagediffence = percentagediff.toFixed(2);
            
            //alert(percentagediffence);
            percentageslab = (percentagediffence/discountPrice)*100;
            percentageslabdis = percentageslab.toFixed(2);
           // alert(percentageslab);
            
            if((percentageslab > "0") && (percentageslab <= "10")  )
            {
                profit1 =  (percentagediffence*5)/100;
               totalprofit = profit1.toFixed(2);
            }
            
            else if((percentageslab > "10") && (percentageslab <= "20")  )
            {
                profit1 =  (percentagediffence*10)/100;
               totalprofit = profit1.toFixed(2);
            }
            
            else if((percentageslab > "20") && (percentageslab <= "30")  )
            {
                profit1 =  (percentagediffence*15)/100;
               totalprofit = profit1.toFixed(2);
            }
            
            else if((percentageslab > "30") && (percentageslab <= "40")  )
            {
                profit1 =  (percentagediffence*20)/100;
               totalprofit = profit1.toFixed(2);
            }
            
            else if((percentageslab > "40") && (percentageslab <= "50")  )
            {
                
               profit1 =  (percentagediffence*25)/100;
               totalprofit = profit1.toFixed(2);
               
            }
            
            else if((percentageslab > "50")   )
            {
               profit1 =  (percentagediffence*40)/100;
               totalprofit = profit1.toFixed(2);
            }
            
            else 
            {
                profit1 =  (percentagediffence*0)/100;
               totalprofit = profit1.toFixed(2);
            }
            
         //alert(percentageslab);
         
        //$('input[name=\'cs_per_qctc[]\']').val(percentageslab);
        table.rows[i].cells[5].innerHTML = discountPrice;
        table.rows[i].cells[7].innerHTML = percentageslabdis;
        table.rows[i].cells[8].innerHTML = percentagediffence;
        table.rows[i].cells[9].innerHTML = totalprofit;
        
        
    
}
</script>

<script src="https://bfccapital.com/crm/assets/js/main.js?v=2.1.1"></script>
                                
                                </tbody>
                            </table>
                            <?php
                        } else {
                            echo "No Incentive Report Found";
                        } 
        
    }
    
    public function delete_wef_sal()
    {
        $wefid = $this->uri->segment('4');
    
        $this->db->where('id', $wefid);
        $this->db->delete('tbl_salary_wef');
        
        set_alert('success', 'W.E.F. Salary Deleted Successfully');
        
        redirect($_SERVER['HTTP_REFERER']);
        
        
    }
    
    public function emp_salary()
    {
        $search = $this->input->post('search', TRUE);
         if (!empty($search)) {
            $data['edit'] = true;
         }
         $user_id = $this->input->post('staff_id', TRUE);
         if (!empty($user_id)) {
            $data['user_id'] = $user_id;
         } else {
            $data['user_id'] = $this->session->userdata('staff_user_id');
         }
         $data['active'] = date('Y');
         //it();
        
         $this->db->select('*');
         $this->db->order_by('department_id');
         $this->db->where('active',1);
         $ignore = array(1, 25,26,52);
         $this->db->where_not_in('staffid', $ignore);
         $data['staff_members'] = $this->db->get('tblstaff')->result_array();
         
         $this->db->select('CONCAT(tblstaff.firstname, " ", tblstaff.lastname) AS  staffname, tblstaff.staffid');
         $this->db->where('active',1);
         $ignore = array(1, 25,26,52);
         $this->db->where_not_in('staffid', $ignore);
         $data['staffs'] = $this->db->get('tblstaff')->result();
         
         $data['list'] = array();
            $month = '10';
            $year = '2020';
            if($month == date("m") && $year == date("Y"))
            {
                $datelimit = date("d");
            }
            else
            {
                $datelimit = '31';
            }
            for($d='1'; $d<=$datelimit; $d++)
            {
                $time=mktime(12, 0, 0, $month, $d, $year);          
                if (date('m', $time)==$month)       
                    $data['list'][]=date('Y-m-d', $time);
            }
         
         $this->load->view('admin/payroll/emp_salary', $data);
    }
    
    public function adjustleavequota()
    {
        echo $staffid = $this->input->post('staffid');
        $bioid = $this->input->post('bioid');
        $actualdd = $this->input->post('actualdd');
        $end = $this->input->post('monthdate');
        $time=strtotime($end);
        $month = date('m', $time);
            $year = date('Y', $time);
            if($month <= '3')
            {
                
                $fi_end_year = $year;
                $fi_start_year = $year-1;
            }
            else
            {
               $fi_end_year = $year+1;
               $fi_start_year = $year; 
            }
        $start = $fi_start_year.'-04-01';
        $staffballeaves = get_leave_summary_satffwise($staffid, @$start, @$end);
        
        if ( !empty($staffballeaves) ) {
                                   foreach ($staffballeaves as $status) { ?>
                                       <td > 
                                              
                                          
                                     
                                              <?php
                                                 if ( isset($status['total']) )          {
                                                     
                                                     
                                                         echo  '<span style="color:#FF0000"> '.$status['leave_category'].'/' . $status['total'] . ' / ' . $status['totalleave'] . ' </span>';
                                                    
                                                     
                                                 }
                                                 else {
                                                      if($status['leave_category'] == 'LWP' && $status['total'] == '')
                                                     {
                                                      echo  '<span style="color:#FF0000"> '.$status['leave_category'].'/' . $status['total'] . ' / ' . $status['totalleave'] . ' </span>';
                                                    
                                                     
                                                  }
                                                     else
                                                     {
                                                      echo  '<span style="color:#FF0000"> '.$status['leave_category'].'/' . $status['total'] . ' / ' . $status['totalleave'] . ' </span>';
                                                    
                                                     
                                                  }
                                                 }
                                              ?>
                                          
                                           
                                       </td>
                                   <?php }
                                } 
        
        
        
        
    }

}